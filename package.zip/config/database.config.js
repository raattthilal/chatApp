module.exports = {
  development: {
    sql: {
      // database: 'suchitwa_mission',
      // username: 'developer',
      // password: 'Projects@2019.com',
      // host: '172.104.61.150',
      
      database: 'suchitwa_mission',
      username: 'root',
      password: 'root',
      host: 'localhost',

      dialect: 'mysql',
      logging:console.log
    }

  },
  

}
