module.exports = {
    development: {
        jwt: { secret:'suchitwamissionecret'}
    },
    qa: {
        jwt: { secret:'suchitwamissionecret'}
    },
};