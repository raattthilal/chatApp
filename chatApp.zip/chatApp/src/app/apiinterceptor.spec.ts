import { Apiinterceptor } from './apiinterceptor';

describe('Apiinterceptor', () => {
  it('should create an instance', () => {
    expect(new Apiinterceptor()).toBeTruthy();
  });
});
